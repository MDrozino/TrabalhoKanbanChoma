package com.example.Kanban;

import org.junit.jupiter.api.Test;



class KanbanApplicationTests {

	@Test
	void contextLoads() {
	}

}
