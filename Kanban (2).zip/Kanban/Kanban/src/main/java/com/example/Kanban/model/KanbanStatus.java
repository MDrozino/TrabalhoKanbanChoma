package com.example.Kanban.model;

public enum KanbanStatus {
    A_FAZER,
    EM_PROGRESSO,
    CONCLUIDO
}
